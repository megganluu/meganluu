#include <iostream>
#include "Composer.h"

/*
recieves a string and integer and declares the name of the composer
and year of death with it
*/
Composer::Composer(string name, int year)
    : composerName(name), yearOfDeath(year)
{}
/*
only recieves the name of the composer and declares the name
*/
Composer::Composer(string name)
    : composerName(name)
{}

/*
returns the name of the composer
*/
string Composer::getName() const {
    return composerName;
}

/*
returns the year of death of the composer
*/
int Composer::getYear() const {
    return yearOfDeath;
}
/*
recieves the composer and outputs the name and year of death
seperated by a dash
*/
ostream& operator<< (ostream& out, const Composer& composer)
{
    out << composer.getName() << " - " << composer.getYear();
    return out;
}

/*
recieves two composers and compares the year of death to whether the first
is lesser than
*/
bool Composer::operator<(const Composer& other) const {
    return yearOfDeath < other.yearOfDeath;
}

/*
recieves two composers and compares the year of death to whether the first
is greater than
*/
bool Composer::operator>(const Composer& other) const {
    return yearOfDeath > other.yearOfDeath;
}

/*
recieves two composers and compares the name and whether they're both the same
*/
bool Composer::operator==(const Composer& other) const {
    return composerName == other.composerName;
}

/*
recieves two composers and compares the name to see if they both aren't the same
*/
bool Composer::operator!=(const Composer& other) const {
    return composerName != other.composerName;
}