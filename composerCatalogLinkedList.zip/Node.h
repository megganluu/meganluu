#include <iostream>
using namespace std;
#pragma once
template <class T>
class Node {

public:
    T data;
    Node<T>* next;
    Node(const T& value) : data(value), next(nullptr) {}
};