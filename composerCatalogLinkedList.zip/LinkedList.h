#pragma once
#include <iostream>
#include "Node.h"
using namespace std;

template <class T>
class LinkedList {
public:
	LinkedList();
	~LinkedList();
    void printList() const;
    void append(const T);
    void prepend(const T);
    void insert(const T);
    bool remove(const T);
    bool find(const T);
    bool isEmpty() const;
    T getFirst() const;
    T getLast() const;

private:
	Node<T> *head;
	Node<T> *tail;
};

/*
default constructor
*/
template <class T>
LinkedList<T>::LinkedList()
{
	head = NULL;
	tail = NULL;
}

template <class T>
/*
destroys constructos
*/
LinkedList<T>::~LinkedList()
{
    Node<T>* current = head;
    while (current != nullptr) {
        Node<T>* next = current->next;
        delete current;
        current = next;
    }
    head = nullptr;
    tail = nullptr;
}

/*
prints the list in order
*/
template <class T>
void LinkedList<T>::printList() const
{
    Node<T>* current = head;
    cout << endl;
    while (current != nullptr)
    {
        cout << current->data << endl;
        current = current->next;
    }
}

/*
recieves T and adds it to the front of the list
*/
template<class T>
void LinkedList<T>::append(const T data) {
    Node<T>* newNode = new Node<T>(data);

    if (head == nullptr) {
        head = newNode;
        tail = newNode;
    }
    else {
        tail->next = newNode;
        tail = newNode;
    }
}

/*
recieves T and adds it to the end of the list while moving everything to the 
front
*/
template<class T>
void LinkedList<T>::prepend(const T data) {
    Node<T>* current = new Node<T>(data);

    if (head == nullptr) {
        head = current;
        tail = current;
    }
    else {
        current->next = head;
        head = current;
    }
}
/*
adds T into its proper place by organizing the other T in the list
throught a loop
*/
template<class T>
void LinkedList<T>::insert(const T data) {
    Node<T>* newNode = new Node<T>(data);

    if (head == nullptr) {
        head = newNode;
        tail = newNode;
    }
    else if (data < head->data) {
        newNode->next = head;
        head = newNode;
    }
    else {
        Node<T>* current = head;
        while (current->next != nullptr && data > current->next->data) {
            current = current->next;
        }
        newNode->next = current->next;
        current->next = newNode;
        if (newNode->next == nullptr) {
            tail = newNode;
        }
    }
}

/*
searches for T in the list and removes it if found
while reorganizing the the other T, returns true if found and false if not
*/
template<class T>
bool LinkedList<T>::remove(const T data) {
    Node<T>* current = head;
    Node<T>* previous = nullptr;

    while (current != nullptr) {
        if (current->data == data) {
            if (current == head) {
                head = current->next;
            }
            else {
                previous->next = current->next;
                if (current == tail) {
                    tail = previous;
                }
            }
            delete current;
            return true;
        }
        previous = current;
        current = current->next;
    }

    return false;
}

/*
attemps to find T in the list and returns true if found and false if not
*/
template<class T>
bool LinkedList<T>::find(const T data) {
    Node<T>* current = head;

    while (current != nullptr)
    {
        if (current->data == data)
        {
            return true;
        }
        current = current->next;
    }

    return false;
}

/*
Determins if the List is empty by checking the head and returns true if it is
and false if it isn't
*/
template<class T>
bool LinkedList<T>::isEmpty() const {
    return head == nullptr;
}
/*
returns the first T in the list
*/
template <class T>
T LinkedList<T>::getFirst() const {
    return head->data;
}

/*
returns the last T in the list
*/
template<class T>
T LinkedList<T>::getLast() const {
    return tail->data;
}