#pragma once
#include <iostream>

using namespace std;

class Composer
{
public:
    Composer(string, int);
    Composer(string);
    string getName() const;
    int getYear() const;
    friend ostream& operator<< (ostream&, const Composer&);
    bool operator<(const Composer&) const;
    bool operator>(const Composer&) const;
    bool operator==(const Composer&) const;
    bool operator!=(const Composer&) const;

private:
	string composerName = "noName";
	int yearOfDeath = 0;
};